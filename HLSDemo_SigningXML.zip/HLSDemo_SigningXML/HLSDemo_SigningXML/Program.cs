﻿using EasySign.Core.New.Demo.SigningAPI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HLSDemo_SigningXML
{
    class Program
    {
        private static string URL = "http://demosign.easyca.vn:8080/api/";
        private static string Username = "demo_easysign";
        private static string Password = "demo_easysign";
        private static string CertSerial = "540110000b4525650231e39369660895"; // Serial cua Chung thu so
        private static string Pin = "079073009568"; // ma pin cua HSM | mat khau cua CTS       
        static void Main(string[] args)
        {
            string filePathToSign = @"C:\Users\admin\Downloads\KySoBADT\BenhAn.xml";
            string content = File.ReadAllText(filePathToSign);
            SigningAPI signingAPI = new SigningAPI(URL, Username, Password);

            // SignedTagId: đẩy tên thẻ cần ký 
            var a = signingAPI.SignXML(CertSerial, Pin, content, SignedTagId:"ad15398f-1df9-4b44-92db-fb1369d16170", null);
        }
    }
}
